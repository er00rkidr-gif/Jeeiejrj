package schematicbrowser.format;

import schematicbrowser.model.Schematic;
import schematicbrowser.nbt.Nbt;
import java.io.IOException;
import java.util.*;

/** Reads Sponge .schem (versions 2 and 3, WorldEdit's format). */
public final class SpongeReader implements SchematicReader {
    @Override
    public Schematic read(byte[] data) throws IOException {
        Map<String, Object> root = Nbt.readGzipped(data);
        Map<String, Object> s = root.containsKey("Schematic") ? Nbt.compound(root, "Schematic") : root;
        int w = Nbt.intOf(s, "Width"), h = Nbt.intOf(s, "Height"), l = Nbt.intOf(s, "Length");

        Map<String, Object> palMap;
        byte[] blockData;
        if (s.containsKey("Blocks")) { // v3
            Map<String, Object> blocks = Nbt.compound(s, "Blocks");
            palMap = Nbt.compound(blocks, "Palette");
            blockData = (byte[]) blocks.get("Data");
        } else { // v2
            palMap = Nbt.compound(s, "Palette");
            blockData = (byte[]) s.get("BlockData");
        }

        int max = -1;
        for (Object v : palMap.values()) max = Math.max(max, ((Number) v).intValue());
        String[] pal = new String[max + 1];
        for (Map.Entry<String, Object> e : palMap.entrySet()) pal[((Number) e.getValue()).intValue()] = e.getKey();

        int[] out = new int[w * h * l];
        int pos = 0;
        for (int i = 0; i < out.length; i++) { // varint decode
            int value = 0, shift = 0, b;
            do {
                b = blockData[pos++];
                value |= (b & 0x7F) << shift;
                shift += 7;
            } while ((b & 0x80) != 0);
            out[i] = value;
        }
        return new Schematic(w, h, l, Arrays.asList(pal), out);
    }
}
