package schematicbrowser.format;

import schematicbrowser.model.Schematic;
import schematicbrowser.nbt.Nbt;
import java.io.IOException;
import java.util.*;

/** Reads .litematic. Multiple regions are merged into one bounding volume. */
public final class LitematicReader implements SchematicReader {
    @Override
    @SuppressWarnings("unchecked")
    public Schematic read(byte[] data) throws IOException {
        Map<String, Object> root = Nbt.readGzipped(data);
        Map<String, Object> regions = Nbt.compound(root, "Regions");
        if (regions == null || regions.isEmpty()) throw new IOException("No regions in litematic");

        int minX = Integer.MAX_VALUE, minY = Integer.MAX_VALUE, minZ = Integer.MAX_VALUE;
        int maxX = Integer.MIN_VALUE, maxY = Integer.MIN_VALUE, maxZ = Integer.MIN_VALUE;
        String[] k = {"x", "y", "z"};
        for (Object o : regions.values()) {
            Map<String, Object> r = (Map<String, Object>) o;
            Map<String, Object> pos = Nbt.compound(r, "Position"), size = Nbt.compound(r, "Size");
            int[] lo = new int[3], hi = new int[3];
            for (int i = 0; i < 3; i++) {
                int p = Nbt.intOf(pos, k[i]), s = Nbt.intOf(size, k[i]);
                int a = p, b = p + (s > 0 ? s - 1 : s + 1);
                lo[i] = Math.min(a, b); hi[i] = Math.max(a, b);
            }
            minX = Math.min(minX, lo[0]); minY = Math.min(minY, lo[1]); minZ = Math.min(minZ, lo[2]);
            maxX = Math.max(maxX, hi[0]); maxY = Math.max(maxY, hi[1]); maxZ = Math.max(maxZ, hi[2]);
        }
        int w = maxX - minX + 1, h = maxY - minY + 1, l = maxZ - minZ + 1;

        List<String> palette = new ArrayList<>();
        Map<String, Integer> paletteIndex = new HashMap<>();
        palette.add(Schematic.AIR); paletteIndex.put(Schematic.AIR, 0);
        int[] out = new int[w * h * l];

        for (Object o : regions.values()) {
            Map<String, Object> r = (Map<String, Object>) o;
            Map<String, Object> pos = Nbt.compound(r, "Position"), size = Nbt.compound(r, "Size");
            int sx = Nbt.intOf(size, "x"), sy = Nbt.intOf(size, "y"), sz = Nbt.intOf(size, "z");
            int ax = Math.abs(sx), ay = Math.abs(sy), az = Math.abs(sz);
            int ox = Nbt.intOf(pos, "x") + (sx < 0 ? sx + 1 : 0);
            int oy = Nbt.intOf(pos, "y") + (sy < 0 ? sy + 1 : 0);
            int oz = Nbt.intOf(pos, "z") + (sz < 0 ? sz + 1 : 0);

            List<Object> rawPalette = Nbt.list(r, "BlockStatePalette");
            int[] remap = new int[rawPalette.size()];
            for (int i = 0; i < remap.length; i++) {
                String s = BlockStates.toString((Map<String, Object>) rawPalette.get(i));
                Integer idx = paletteIndex.get(s);
                if (idx == null) { idx = palette.size(); palette.add(s); paletteIndex.put(s, idx); }
                remap[i] = idx;
            }
            long[] packed = (long[]) r.get("BlockStates");
            int bits = Math.max(2, 32 - Integer.numberOfLeadingZeros(Math.max(1, rawPalette.size() - 1)));
            long mask = (1L << bits) - 1;
            long total = (long) ax * ay * az;
            for (long i = 0; i < total; i++) {
                long bitPos = i * bits;
                int word = (int) (bitPos >>> 6), off = (int) (bitPos & 63);
                long v = packed[word] >>> off;
                if (off + bits > 64) v |= packed[word + 1] << (64 - off);
                int local = remap[(int) (v & mask)];
                if (local == 0) continue;
                int lx = (int) (i % ax), lz = (int) ((i / ax) % az), ly = (int) (i / ((long) ax * az));
                int x = ox + lx - minX, y = oy + ly - minY, z = oz + lz - minZ;
                out[x + z * w + y * w * l] = local;
            }
        }
        return new Schematic(w, h, l, palette, out);
    }
}
