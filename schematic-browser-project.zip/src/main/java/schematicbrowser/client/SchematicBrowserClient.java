package schematicbrowser.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public class SchematicBrowserClient implements ClientModInitializer {
    private static KeyBinding openBrowser;

    @Override
    public void onInitializeClient() {
        // Shows up in Options > Controls under "Schematic Browser". Default key: B.
        // NOTE: this is the pre-1.21.9 form (category as a String). On 1.21.9+ the category must be a
        // KeyBinding.Category object instead - tell me your version and I'll match it.
        openBrowser = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.schematicbrowser.open",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_B,
                "category.schematicbrowser"));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openBrowser.wasPressed()) {
                if (client.player != null) {
                    // TODO: replace with client.setScreen(new BrowserScreen()) once the screen exists.
                    client.player.sendMessage(Text.literal("Schematic browser: coming soon"), true);
                }
            }
        });
    }
}
