package schematicbrowser.model;

import java.util.List;

/** Format-independent block volume. Index = x + z*width + y*width*length. */
public final class Schematic {
    public static final String AIR = "minecraft:air";

    public final int width, height, length;
    public final List<String> palette;   // e.g. minecraft:oak_stairs[facing=north,half=bottom]
    public final int[] blocks;           // palette indices

    public Schematic(int width, int height, int length, List<String> palette, int[] blocks) {
        this.width = width; this.height = height; this.length = length;
        this.palette = palette; this.blocks = blocks;
    }

    public int index(int x, int y, int z) { return x + z * width + y * width * length; }
    public String stateAt(int x, int y, int z) { return palette.get(blocks[index(x, y, z)]); }
    public boolean isAir(String state) {
        return state.equals(AIR) || state.startsWith("minecraft:cave_air") || state.startsWith("minecraft:void_air");
    }
    public long nonAirCount() {
        long n = 0;
        for (int b : blocks) if (!isAir(palette.get(b))) n++;
        return n;
    }
}
