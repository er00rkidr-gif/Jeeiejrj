package schematicbrowser.nbt;

import java.io.*;
import java.util.*;
import java.util.zip.GZIPInputStream;

/** Minimal NBT reader. Compounds -> Map, lists -> List, arrays -> byte[]/int[]/long[], numbers -> boxed types. */
public final class Nbt {
    private Nbt() {}

    @SuppressWarnings("unchecked")
    public static Map<String, Object> readGzipped(byte[] data) throws IOException {
        try (DataInputStream in = new DataInputStream(new BufferedInputStream(
                new GZIPInputStream(new ByteArrayInputStream(data))))) {
            int type = in.readUnsignedByte();
            if (type != 10) throw new IOException("Root tag is not a compound");
            in.readUTF(); // root name
            return (Map<String, Object>) readPayload(in, 10);
        }
    }

    private static Object readPayload(DataInputStream in, int type) throws IOException {
        switch (type) {
            case 1: return in.readByte();
            case 2: return in.readShort();
            case 3: return in.readInt();
            case 4: return in.readLong();
            case 5: return in.readFloat();
            case 6: return in.readDouble();
            case 7: { byte[] a = new byte[in.readInt()]; in.readFully(a); return a; }
            case 8: return in.readUTF();
            case 9: {
                int elem = in.readUnsignedByte();
                int len = in.readInt();
                List<Object> list = new ArrayList<>(len);
                for (int i = 0; i < len; i++) list.add(readPayload(in, elem));
                return list;
            }
            case 10: {
                Map<String, Object> map = new LinkedHashMap<>();
                while (true) {
                    int t = in.readUnsignedByte();
                    if (t == 0) break;
                    String name = in.readUTF();
                    map.put(name, readPayload(in, t));
                }
                return map;
            }
            case 11: { int[] a = new int[in.readInt()]; for (int i = 0; i < a.length; i++) a[i] = in.readInt(); return a; }
            case 12: { long[] a = new long[in.readInt()]; for (int i = 0; i < a.length; i++) a[i] = in.readLong(); return a; }
            default: throw new IOException("Unknown NBT tag type " + type);
        }
    }

    @SuppressWarnings("unchecked")
    public static Map<String, Object> compound(Map<String, Object> m, String k) { return (Map<String, Object>) m.get(k); }
    @SuppressWarnings("unchecked")
    public static List<Object> list(Map<String, Object> m, String k) { return (List<Object>) m.get(k); }
    public static int intOf(Map<String, Object> m, String k) { return ((Number) m.get(k)).intValue(); }
}
