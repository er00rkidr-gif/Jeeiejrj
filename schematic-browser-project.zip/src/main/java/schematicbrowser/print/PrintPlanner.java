package schematicbrowser.print;

import schematicbrowser.model.Schematic;
import java.util.ArrayList;
import java.util.List;

/**
 * Turns a schematic into few /fill and /setblock commands by greedily merging identical
 * neighbouring blocks into boxes. Vanilla caps /fill at 32768 blocks per command.
 */
public final class PrintPlanner {
    public static final int MAX_FILL_VOLUME = 32768;

    private PrintPlanner() {}

    public static List<String> plan(Schematic s, int originX, int originY, int originZ) {
        int w = s.width, h = s.height, l = s.length;
        boolean[] done = new boolean[w * h * l];
        List<String> cmds = new ArrayList<>();

        for (int y = 0; y < h; y++)
            for (int z = 0; z < l; z++)
                for (int x = 0; x < w; x++) {
                    int i = s.index(x, y, z);
                    if (done[i]) continue;
                    int id = s.blocks[i];
                    if (s.isAir(s.palette.get(id))) { done[i] = true; continue; }

                    int x2 = x;
                    while (x2 + 1 < w && same(s, done, x2 + 1, y, z, id) && vol(x2 + 2 - x, 1, 1) <= MAX_FILL_VOLUME) x2++;
                    int z2 = z;
                    while (z2 + 1 < l && rowSame(s, done, x, x2, y, z2 + 1, id) && vol(x2 - x + 1, 1, z2 + 2 - z) <= MAX_FILL_VOLUME) z2++;
                    int y2 = y;
                    while (y2 + 1 < h && layerSame(s, done, x, x2, y2 + 1, z, z2, id)
                            && vol(x2 - x + 1, y2 + 2 - y, z2 - z + 1) <= MAX_FILL_VOLUME) y2++;

                    for (int yy = y; yy <= y2; yy++)
                        for (int zz = z; zz <= z2; zz++)
                            for (int xx = x; xx <= x2; xx++) done[s.index(xx, yy, zz)] = true;

                    String state = s.palette.get(id);
                    if (x == x2 && y == y2 && z == z2)
                        cmds.add("setblock " + (originX + x) + " " + (originY + y) + " " + (originZ + z) + " " + state);
                    else
                        cmds.add("fill " + (originX + x) + " " + (originY + y) + " " + (originZ + z) + " "
                                + (originX + x2) + " " + (originY + y2) + " " + (originZ + z2) + " " + state);
                }
        return cmds;
    }

    private static long vol(int a, int b, int c) { return (long) a * b * c; }
    private static boolean same(Schematic s, boolean[] done, int x, int y, int z, int id) {
        int i = s.index(x, y, z);
        return !done[i] && s.blocks[i] == id;
    }
    private static boolean rowSame(Schematic s, boolean[] done, int x1, int x2, int y, int z, int id) {
        for (int x = x1; x <= x2; x++) if (!same(s, done, x, y, z, id)) return false;
        return true;
    }
    private static boolean layerSame(Schematic s, boolean[] done, int x1, int x2, int y, int z1, int z2, int id) {
        for (int z = z1; z <= z2; z++) if (!rowSame(s, done, x1, x2, y, z, id)) return false;
        return true;
    }
}
