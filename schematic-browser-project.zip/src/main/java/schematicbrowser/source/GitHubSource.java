package schematicbrowser.source;

import com.google.gson.*;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Lists schematics from configured GitHub repos (unauthenticated contents API, one directory level). */
public final class GitHubSource implements SchematicSource {
    private final List<String> repoPaths; // "owner/repo" or "owner/repo/path/to/dir"

    public GitHubSource(List<String> repoPaths) { this.repoPaths = repoPaths; }
    public String id() { return "github"; }
    public String displayName() { return "GitHub repos"; }

    public List<SchematicEntry> search(String query) throws IOException, InterruptedException {
        List<SchematicEntry> out = new ArrayList<>();
        String q = query.toLowerCase();
        for (String rp : repoPaths) {
            String[] p = rp.split("/", 3);
            String url = "https://api.github.com/repos/" + p[0] + "/" + p[1] + "/contents/" + (p.length > 2 ? p[2] : "");
            JsonArray arr = JsonParser.parseString(new String(Http.getBytes(url), StandardCharsets.UTF_8)).getAsJsonArray();
            for (JsonElement el : arr) {
                JsonObject o = el.getAsJsonObject();
                String name = o.get("name").getAsString();
                String lower = name.toLowerCase();
                if (!(lower.endsWith(".litematic") || lower.endsWith(".schem"))) continue;
                if (!q.isBlank() && !lower.contains(q)) continue;
                out.add(new SchematicEntry(o.get("sha").getAsString(), name, p[0], null,
                        o.get("download_url").getAsString(), name));
            }
        }
        return out;
    }
    public byte[] download(SchematicEntry e) throws IOException, InterruptedException { return Http.getBytes(e.downloadUrl()); }
}
